const listaPokemon = document.querySelector("#listaPokemon");
const botonesHeader = document.querySelectorAll(".btn-header");
const pokemonInput = document.querySelector("#pokemon-input");
let URL = "https://pokeapi.co/api/v2/pokemon/";
let todosLosPokemon = [];

async function cargarDatosIniciales() {
    for (let i = 1; i <= 151; i++) {
        try {
            const response = await fetch(URL + i);
            const data = await response.json();
            todosLosPokemon.push(data);
        } catch (error) {
            console.error(error);
        }
    }
    mostrarLista(todosLosPokemon);
}

function mostrarPokemon(poke) {
    let tipos = poke.types.map((type) => `<p class="${type.type.name} tipo">${type.type.name}</p>`);
    tipos = tipos.join('');

    let pokeId = poke.id.toString().padStart(3, '0');
    const habilidades = poke.abilities.map(hab => hab.ability.name).join(", ");

    const div = document.createElement("div");
    div.classList.add("pokemon");
    div.innerHTML = `
        <p class="pokemon-id-back">#${pokeId}</p>
        <div class="pokemon-imagen">
            <img src="${poke.sprites.other["official-artwork"].front_default}" alt="${poke.name}">
        </div>
        <div class="pokemon-info">
            <div class="nombre-contenedor">
                <p class="pokemon-id">#${pokeId}</p>
                <h2 class="pokemon-nombre">${poke.name}</h2>
            </div>
            <div class="pokemon-tipos">
                ${tipos}
            </div>
            <div class="pokemon-stats">
                <p class="stat">${poke.height}m</p>
                <p class="stat">${poke.weight}kg</p>
            </div>
            <div class="pokemon-stats">
                <p class="stat"><strong>Habilidades:</strong> ${habilidades}</p>
            </div>
        </div>
    `;
    listaPokemon.append(div);
}

function mostrarLista(lista) {
    listaPokemon.innerHTML = "";
    if (lista.length === 0) {
        listaPokemon.innerHTML = `<p class="error-mensaje">No se encontraron Pokémon con ese nombre</p>`;
        return;
    }
    lista.forEach(poke => mostrarPokemon(poke));
}

pokemonInput.addEventListener("input", (e) => {
    const valor = e.target.value.toLowerCase().trim();
    const filtrados = todosLosPokemon.filter(poke => 
        poke.name.toLowerCase().includes(valor) || 
        poke.id.toString().includes(valor)
    );
    mostrarLista(filtrados);
});

botonesHeader.forEach(boton => boton.addEventListener("click", (event) => {
    const botonId = event.currentTarget.id;
    pokemonInput.value = "";

    if (botonId === "ver-todos") {
        mostrarLista(todosLosPokemon);
    } else {
        const filtradosPorTipo = todosLosPokemon.filter(poke => {
            const tipos = poke.types.map(type => type.type.name);
            return tipos.includes(botonId);
        });
        mostrarLista(filtradosPorTipo);
    }
}));

cargarDatosIniciales();